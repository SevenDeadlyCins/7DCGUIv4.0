/********************************************************************************
** Form generated from reading UI file 'sevencins.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEVENCINS_H
#define UI_SEVENCINS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SevenCins
{
public:
    QWidget *centralWidget;
    QPushButton *searchButton;
    QPushButton *randomDrinkButton;
    QPushButton *showFavoritesButton;
    QPushButton *showCabinetButton;
    QFrame *drinkPictureFrame;
    QGraphicsView *drinkPicture;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SevenCins)
    {
        if (SevenCins->objectName().isEmpty())
            SevenCins->setObjectName(QStringLiteral("SevenCins"));
        SevenCins->resize(600, 394);
        centralWidget = new QWidget(SevenCins);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        searchButton = new QPushButton(centralWidget);
        searchButton->setObjectName(QStringLiteral("searchButton"));
        searchButton->setGeometry(QRect(50, 30, 75, 23));
        searchButton->setToolTipDuration(5);
        randomDrinkButton = new QPushButton(centralWidget);
        randomDrinkButton->setObjectName(QStringLiteral("randomDrinkButton"));
        randomDrinkButton->setGeometry(QRect(50, 330, 75, 23));
        randomDrinkButton->setToolTipDuration(5);
        randomDrinkButton->setCheckable(true);
        showFavoritesButton = new QPushButton(centralWidget);
        showFavoritesButton->setObjectName(QStringLiteral("showFavoritesButton"));
        showFavoritesButton->setGeometry(QRect(260, 330, 75, 23));
        showFavoritesButton->setToolTipDuration(5);
        showCabinetButton = new QPushButton(centralWidget);
        showCabinetButton->setObjectName(QStringLiteral("showCabinetButton"));
        showCabinetButton->setGeometry(QRect(480, 330, 75, 23));
        showCabinetButton->setToolTipDuration(5);
        drinkPictureFrame = new QFrame(centralWidget);
        drinkPictureFrame->setObjectName(QStringLiteral("drinkPictureFrame"));
        drinkPictureFrame->setGeometry(QRect(60, 70, 181, 181));
        drinkPictureFrame->setFrameShape(QFrame::StyledPanel);
        drinkPictureFrame->setFrameShadow(QFrame::Sunken);
        drinkPicture = new QGraphicsView(drinkPictureFrame);
        drinkPicture->setObjectName(QStringLiteral("drinkPicture"));
        drinkPicture->setGeometry(QRect(10, 10, 161, 161));
        SevenCins->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(SevenCins);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        SevenCins->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(SevenCins);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        SevenCins->setStatusBar(statusBar);

        retranslateUi(SevenCins);
        QObject::connect(randomDrinkButton, SIGNAL(clicked()), randomDrinkButton, SLOT(click()));
        QObject::connect(showFavoritesButton, SIGNAL(clicked()), showFavoritesButton, SLOT(click()));
        QObject::connect(showCabinetButton, SIGNAL(clicked()), showCabinetButton, SLOT(click()));
        QObject::connect(searchButton, SIGNAL(clicked()), searchButton, SLOT(click()));

        QMetaObject::connectSlotsByName(SevenCins);
    } // setupUi

    void retranslateUi(QMainWindow *SevenCins)
    {
        SevenCins->setWindowTitle(QApplication::translate("SevenCins", "7SV4.0", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        searchButton->setToolTip(QApplication::translate("SevenCins", "Search for a drink or a specific ingredient.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        searchButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        searchButton->setText(QApplication::translate("SevenCins", "Search", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        randomDrinkButton->setToolTip(QApplication::translate("SevenCins", "Shows a random drink. Try something new!", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        randomDrinkButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        randomDrinkButton->setText(QApplication::translate("SevenCins", "Surprise Me!", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        showFavoritesButton->setToolTip(QApplication::translate("SevenCins", "Show your list of favorites.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        showFavoritesButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        showFavoritesButton->setText(QApplication::translate("SevenCins", "Favorites", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        showCabinetButton->setToolTip(QApplication::translate("SevenCins", "Shows what is currently in your cabinet.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        showCabinetButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        showCabinetButton->setText(QApplication::translate("SevenCins", "My Cabinet", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class SevenCins: public Ui_SevenCins {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEVENCINS_H
