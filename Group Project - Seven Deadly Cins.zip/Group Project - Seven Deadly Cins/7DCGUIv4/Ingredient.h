/*
Chawon White - 000833921
CS441 - Software Engineering
Group Project - Ingredient Class
Ingredient.h - Ingredient class file with defined functions.
*/

#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;

#ifndef INGREDIENT_H
#define INGREDIENT_H

/*
Enumeration for Price:
Price of ingredient is represented by low, mid, or high.
As of 10/07/2019, price is not represented by a dollar
amount.
*/
enum price
{
        low = 1, mid = 2, high = 3
};

/*
Enumeration for Type:
Type of ingredient is either liquid or garnish.
*/
enum type
{
        liquid, garnish
};

/*
Ingredient Class:
The ingredient class is one of the base classes for the
project. This class is used by other classes.
*/
class Ingredient
{
private:
        string name;
        type iType;
        int proof;
        price iPrice;
public:
        /*
        Ingredient(string newN, type newT, int newI, price newP):
        The ingredient constructor- for now, we assume that an ingredient
        will get all of the necessary parts at creation. To make one code
        path, this constructor calls setIngredient().
        */
        Ingredient(string newN, type newT, int newI, price newP)
        {
                this->setIngredient(newN, newT, newI, newP);
        }

        /*
        void setIngredient():
        The main function in the ingredient class. Each piece of data is
        passed in when an instance of this class is created.
        */
        void setIngredient(string n, type t, int i, price p)
        {
                this->name = n;
                this->iType = t;
                this->proof = i;
                this->iPrice = p;
        }

        /*
        string getName():
        Returns the name of the ingredient.
        */
        string getName()
        {
                return this->name;
        }

        /*
        type getType():
        Returns the type enumeration.
        */
        type getType()
        {
                return this->iType;
        }

        /*
        int getProof():
        Returns the proof as an int.
        */
        int getProof()
        {
                return this->proof;
        }

        /*
        price getPrice()
        Returns the price enumeration.
        */
        price getPrice()
        {
                return this->iPrice;
        }

};


#endif
