#include "sevencins.h"
#include "ui_sevencins.h"

SevenCins::SevenCins(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::SevenCins)
{
    drinkPictureInfo = new QLabel();
    drinkInfo = new QTextEdit();

    drinkPictureInfo->setAlignment(Qt::AlignHCenter);
    drinkPictureInfo->setText("Welcome to 7DC");
    drinkInfo->setText(QString("Under Construction. Buttons will crash the GUI until the backend is linked to the GUI properly."));
    drinkPictureInfo->resize(180, 20);
    drinkInfo->resize(260, 180);

    drinkPictureInfo->setFrameShape(QAbstractScrollArea::Box);
    this->layout()->addWidget(drinkInfo);
    this->layout()->addWidget(drinkPictureInfo);

    drinkPictureInfo->move(60, 280);
    drinkInfo->move(320, 80);
    ui->setupUi(this);
}

SevenCins::~SevenCins()
{
    delete ui;
}


void SevenCins::on_randomDrinkButton_clicked()
{
    qrand();
    unsigned int random = 0;
    Drink randomDrink = drinkList.at(random);
    drinkPictureInfo->setText(QString::fromStdString(randomDrink.getName()));
    QString loadimage = QString::fromStdString(randomDrink.getImageString());


    QGraphicsScene* scene = new QGraphicsScene();
    QPixmap drinkPictures(loadimage);
    scene->setBackgroundBrush(drinkPictures.scaled(100,100,Qt::IgnoreAspectRatio,Qt::SmoothTransformation));
    ui->drinkPicture->setScene(scene);
    drinkInfo->clear();
    drinkInfo->append(QString::fromStdString(randomDrink.getDrinkDescription()));
}

void SevenCins::on_showFavoritesButton_clicked()
{

}

void SevenCins::on_showCabinetButton_clicked()
{

}
