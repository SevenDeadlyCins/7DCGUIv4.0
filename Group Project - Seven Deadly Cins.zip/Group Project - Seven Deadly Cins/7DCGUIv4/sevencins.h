#ifndef SEVENCINS_H
#define SEVENCINS_H

#include <QMainWindow>
#include <QApplication>
#include <QGridLayout>
#include <QSplitter>
#include <QPushButton>
#include <QMessageBox>
#include <QTextBlock>
#include <QTextEdit>
#include <QLabel>

#include "Drink.h"
#include "Recipe.h"

QT_BEGIN_NAMESPACE
namespace Ui { class SevenCins; }
QT_END_NAMESPACE

class SevenCins : public QMainWindow
{
    Q_OBJECT

public:
    SevenCins(QWidget *parent = nullptr);
    ~SevenCins();

private slots:
    void on_randomDrinkButton_clicked();

    void on_showFavoritesButton_clicked();

    void on_showCabinetButton_clicked();

private:
    Ui::SevenCins *ui;
    std::vector<Drink> drinkList;
    QLabel *drinkPictureInfo;
    QTextEdit *drinkInfo;
};
#endif // SEVENCINS_H
