#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include "Recipe.h"
using namespace std;
#ifndef DRINK_H
#define DRINK_H
//Class declaration
class Drink
{
private:
    string name;
    Recipe rec;
    string alc_cont;
    string imageName = NULL;
    //visit num_vis;
    //Picture pic;

public:
    Drink(string drinkName, Recipe recip, string content)
    {
        this->name = drinkName;
        this->rec = recip;
        this->alc_cont = content;
    }
    //int calculate_alcohol();
    string getName(){return name;}
    void setName(string drinkName){this->name = drinkName;}
    string getImageString(){ return imageName; }
    string getDrinkDescription(){ return "works fine"; }
    void displayDrink();
};

//(Alc content * Liquor Volume) / Drink Volume
//0 = None, 1-25 = Light, 26-50 Medium, 50+ = Heavy

#endif
